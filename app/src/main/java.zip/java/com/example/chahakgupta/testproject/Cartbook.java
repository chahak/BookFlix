package com.example.chahakgupta.testproject;

public class Cartbook {
	public String code;
    public String name;
    public String publisher;
    public String price;
    public String author;

    public Cartbook(String code,String name, String publisher, String price, String author) {
    	this.code = code;
       this.name = name;
       this.publisher = publisher;
       this.price = price;
       this.author = author;
    }
}