package com.example.chahakgupta.testproject;

public class User {
	public  String rollno;
	public  String name;
	public  String password;
	public  String branch;
	public  String year;

	    public User(String rollno, String name,String password,String branch,String year) {
	    	this.rollno = rollno;
	    	this.name = name;
	       this.password = password;
	       this.branch = branch;
	       this.year = year;
	    }
}
